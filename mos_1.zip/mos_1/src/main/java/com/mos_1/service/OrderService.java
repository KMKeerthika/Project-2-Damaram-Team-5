package com.mos_1.service;

import java.util.List;

import com.mos_1.entity.OrderDetails;


public interface OrderService 
{
	OrderDetails create(OrderDetails OrderDetails);
	OrderDetails update(OrderDetails OrderDetails);
	void delete(String site);
	List<OrderDetails> showAll();
}
