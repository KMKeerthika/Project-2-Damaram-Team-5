package com.mos_1.service;

import java.util.List;

import com.mos_1.entity.Order;


public interface OrderService 
{
	Order create(Order order);
	Order update(Order order);
	List<Order> delete(int orderId);
	List<Order> showAll();
}
