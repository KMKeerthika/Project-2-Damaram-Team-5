package com.mos_1.service;

import java.util.List;

import com.mos_1.entity.MaintainExclusion;

public interface MaintainExclusionService 
{
	MaintainExclusion createMaintainExclusion(MaintainExclusion MaintainExclusion);
	MaintainExclusion updateMaintainExclusion(MaintainExclusion MaintainExclusion);
	void deleteMaintainExclusion(String site);
	List<MaintainExclusion> showAllMaintainExclusion();
}
