package com.mos_1.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mos_1.entity.MaintainExclusion;
import com.mos_1.repo.MaintainExclusionRepo;
import com.mos_1.service.MaintainExclusionService;

@Service
public class MaintainExclusionServiceImpl implements MaintainExclusionService
{
	@Autowired
	MaintainExclusionRepo repo;

	@Override
	public MaintainExclusion createMaintainExclusion(MaintainExclusion MaintainExclusion) 
	{
		return repo.save(MaintainExclusion);
	}

	@Override
	public MaintainExclusion updateMaintainExclusion(MaintainExclusion MaintainExclusion) 
	{
		return repo.saveAndFlush(MaintainExclusion);
	}

	@Override
	public void deleteMaintainExclusion(String site) 
	{
		repo.deleteById(site);
		
	}

	@Override
	public List<MaintainExclusion> showAllMaintainExclusion() 
	{
		return repo.findAll();
	}
	
	
}
