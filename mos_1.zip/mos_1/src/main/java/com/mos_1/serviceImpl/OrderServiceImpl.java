package com.mos_1.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mos_1.entity.OrderDetails;
import com.mos_1.repo.OrderRepo;
import com.mos_1.service.OrderService;

@Service
public class OrderServiceImpl implements OrderService
{
	@Autowired
	OrderRepo repo;

	@Override
	public OrderDetails create(OrderDetails OrderDetails) 
	{
		return repo.save(OrderDetails);
	}

	@Override
	public OrderDetails update(OrderDetails OrderDetails) 
	{
		return repo.saveAndFlush(OrderDetails);
	}

	

	@Override
	public List<OrderDetails> showAll() 
	{
		return repo.findAll();
	}

	@Override
	public void delete(String site)
	{
		repo.deleteById(site);
		
	}

}
