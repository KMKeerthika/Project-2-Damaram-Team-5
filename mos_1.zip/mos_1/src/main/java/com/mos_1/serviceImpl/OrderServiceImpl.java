package com.mos_1.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mos_1.entity.Order;
import com.mos_1.repo.OrderRepo;
import com.mos_1.service.OrderService;

@Service
public class OrderServiceImpl implements OrderService
{
	@Autowired
	OrderRepo repo;

	@Override
	public Order create(Order order) 
	{
		return repo.save(order);
	}

	@Override
	public Order update(Order order) 
	{
		return repo.saveAndFlush(order);
	}

	@Override
	public List<Order> delete(int orderId) 
	{
		repo.deleteById(orderId);
		return repo.findAll();
	}

	@Override
	public List<Order> showAll() 
	{
		return repo.findAll();
	}

}
