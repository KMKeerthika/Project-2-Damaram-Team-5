package com.mos_1.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.mos_1.entity.MaintainExclusion;

@Repository
public interface MaintainExclusionRepo extends JpaRepository<MaintainExclusion, String>{

}
