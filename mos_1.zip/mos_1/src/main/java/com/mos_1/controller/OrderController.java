package com.mos_1.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mos_1.entity.Order;
import com.mos_1.service.OrderService;

@RestController
public class OrderController 
{
	@Autowired
	OrderService service;
	
	@PostMapping("/create")
	public Order Create(@RequestBody Order order)
	{
		System.out.println(order);
		return service.create(order);
	}
	
	@PostMapping("/update")
	public Order Update(@RequestBody Order order)
	{
		return service.update(order);
	}
	
	@GetMapping("/delete")
	public List<Order> Delete(@RequestBody int orderId)
	{
		return service.delete(orderId);
	}
	
	@GetMapping("/showAll")
	public List<Order> showAll()
	{
		return service.showAll();
	}
}
