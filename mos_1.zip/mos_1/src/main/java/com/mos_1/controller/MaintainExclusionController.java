package com.mos_1.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mos_1.entity.MaintainExclusion;
import com.mos_1.service.MaintainExclusionService;

@RestController
public class MaintainExclusionController 
{
	@Autowired
	MaintainExclusionService service;
	
	@PostMapping("/createMaintainExclusion")
	public MaintainExclusion createMaintainExclusion(@RequestBody MaintainExclusion MaintainExclusion)
	{
		return service.createMaintainExclusion(MaintainExclusion);
	}
	
	@PostMapping("/updateMaintainExclusion")
	public MaintainExclusion updateMaintainExclusion(@RequestBody MaintainExclusion MaintainExclusion)
	{
		return service.updateMaintainExclusion(MaintainExclusion);
	}
	
	@DeleteMapping("/deleteMaintainExclusion")
	public void deleteMaintainExclusion(@RequestBody String site)
	{
		service.deleteMaintainExclusion(site);
	}
	
	@GetMapping("/showAllMaintainExclusion")
	public List<MaintainExclusion> showAllMaintainExclusion()
	{
		return service.showAllMaintainExclusion();
	}
}
