package com.mos_1.entityKey;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class MaintainExclusionKey implements Serializable
{
	 
	  private String site;
	  
	  private String nationalId;

	  private String customerNumber;
}
