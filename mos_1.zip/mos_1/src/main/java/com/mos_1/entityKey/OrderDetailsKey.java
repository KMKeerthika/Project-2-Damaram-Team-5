package com.mos_1.entityKey;

import java.io.Serializable;
import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class OrderDetailsKey implements Serializable
{

	@NonNull
	private String site;
	@NonNull
	private BigDecimal orderNumber;
	@NonNull
	private BigDecimal orderDetailLineNumber;
}
