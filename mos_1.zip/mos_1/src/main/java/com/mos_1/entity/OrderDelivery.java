package com.mos_1.entity;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor
public class OrderDelivery 
{
	@Id
	@Column
	private int orderId;
	
	@Basic
	@Column
	private String OrderAddress;
	
	@Basic
	@Column
	private Long pincode;
}
