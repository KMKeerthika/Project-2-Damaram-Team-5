package com.mos_1.entity;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@Table
@AllArgsConstructor
@NoArgsConstructor
public class Order 
{
	@Id
	@Column
	@JsonProperty("orderId")
	private int orderId;
	
	@Basic
	@Column
	@JsonProperty("orderQuantity")
	private int orderQuantity;
	
	@Basic
	@Column
	@JsonProperty("orderPrice")
	private int orderPrice;

	@Override
	public String toString() {
		return "Order [orderId=" + orderId + ", orderQuantity=" + orderQuantity + ", orderPrice=" + orderPrice + "]";
	}

	
	
}
