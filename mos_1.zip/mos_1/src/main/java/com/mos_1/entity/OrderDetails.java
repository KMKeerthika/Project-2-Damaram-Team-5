package com.mos_1.entity;

import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.mos_1.entityKey.OrderDetailsKey;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;


@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Table(name = "orderDetails")
@Entity
@Getter
@Setter
@IdClass(value=OrderDetailsKey.class)
public class OrderDetails
{
	@Id
	@Column(name = "site",unique=true, nullable=false)
	@JsonProperty("site")
	private String site;
	 
	 @Id
	 @Column(name=" order_number",unique=true, nullable=false)
	 @JsonProperty("orderNumber")
	 private BigDecimal orderNumber;
	 
	 @Id
	 @Column(name="order_detail_line_number",unique=true, nullable=false)
	 @JsonProperty("orderDetailLineNumber")
	 private BigDecimal orderDetailLineNumber;
	 
	 @Basic
	 @Column(name="order_entry_line_type")
	 @JsonProperty("orderEntryLineType")
	 private String orderEntryLineType;
	 
	 @Basic
	 @Column(name=" item_number")
	 @JsonProperty("itemNumber")
	 private String itemNumber;
	 
	 @Basic
	 @Column(name="item_description")
	 @JsonProperty("itemDescription")
	 private String itemDescription;
	 
	 @Basic
	 @Column(name="locn_code")
	 @JsonProperty("locnCode")
	 private String locnCode;
	 
	 @Basic
	 @Column(name="alternates_indicator")
	 @JsonProperty("alternatesIndicator")
	 private String alternatesIndicator;
	 
	 @Basic
	 @Column(name="companions_indicator")
	 @JsonProperty("companionsIndicator")
	 private String companionsIndicator;
	 
	 @Basic
	 @Column(name="order_detail_notes_indicator")
	 @JsonProperty("orderDetailNotesIndicator")
	 private String orderDetailNotesIndicator;
	 
	 @Basic
	 @Column(name="drop_ship_indicator")
	 @JsonProperty("dropShipIndicator")
	 private String dropShipIndicator;
	 
	 @Basic
	 @Column(name="pricing_agreements_indicator")
	 @JsonProperty("pricingAgreementsIndicator")
	 private String pricingAgreementsIndicator;
	 
	 @Basic
	 @Column(name="quantity")
	 @JsonProperty("quantity")
	 private BigDecimal quantity;
	 
	 @Basic
	 @Column(name="split_code")
	 @JsonProperty("splitCode")
	 private String splitCode;
	 
	 @Basic
	 @Column(name="quantity_alloc_against_on_hand ")
	 @JsonProperty("quantityAllocAgainstOnHand")
	 private BigDecimal quantityAllocAgainstOnHand;
	 
	 @Basic
	 @Column(name="quantity_alloc_against_sch_receipts")
	 @JsonProperty("quantityAllocAgainstSchReceipts")
	 private BigDecimal quantityAllocAgainstSchReceipts;
	 
	 @Basic
	 @Column(name=" order_detail_allocated ")
	 @JsonProperty("orderDetailAllocated")
	 private String orderDetailAllocated;
	 
	 @Basic
	 @Column(name="ship_date")
	 @JsonProperty("shipDate")
	 private BigDecimal shipDate;
	 
	 @Basic
	 @Column(name="shipped_quantity")
	 @JsonProperty("shippedQuantity")
	 private BigDecimal shippedQuantity;
	 
	 @Basic
	 @Column(name="original_item_unit_price")
	 @JsonProperty("originalItemUnitPrice")
	 private BigDecimal originalItemUnitPrice;
	 
	 @Basic
	 @Column(name=" order_detail_extended_price")
	 @JsonProperty("orderDetailExtendedPrice")
	 private BigDecimal orderDetailExtendedPrice;
	 
	 @Basic
	 @Column(name=" suggested_price ")
	 @JsonProperty("suggestedPrice")
	 private BigDecimal suggestedPrice;
	 
	 @Basic
	 @Column(name="hand_price_flag")
	 @JsonProperty("handPriceFlag")
	 private String handPriceFlag;
	 
	 @Basic
	 @Column(name="order_guide_number")
	 @JsonProperty("orderGuideNumber")
	 private BigDecimal orderGuideNumber;
	 
	 @Basic
	 @Column(name="order_guide_line_no")
	 @JsonProperty("orderGuideLineNo")
	 private String orderGuideLineNo;
	 
	 @Basic
	 @Column(name="customer_item_no")
	 @JsonProperty("customerItemNo")
	 private String customerItemNo;
	 
	 @Basic
	 @Column(name="customer_ship_to")
	 @JsonProperty("customerShipTo")
	 private String customerShipTo;
	 
	 @Basic
	 @Column(name="shipping_address_id")
	 @JsonProperty("shippingAddressId")
	 private String shippingAddressId;
	 
	 @Basic
	 @Column(name="customer_category_code")
	 @JsonProperty("customerCategoryCode")
	 private String customerCategoryCode;
	 
	 @Basic
	 @Column(name="routing_group_code")
	 @JsonProperty("routingGroupCode")
	 private BigDecimal routingGroupCode;
	 
	 @Basic
	 @Column(name="request_number")
	 @JsonProperty("requestNumber")
	 private BigDecimal requestNumber;
	 
	 @Basic
	 @Column(name="vendor_number ")
	 @JsonProperty("vendorNumber")
	 private String vendorNumber;
	 
	 @Basic
	 @Column(name="vendor_pay_flag")
	 @JsonProperty("vendorPayFlag")
	 private String vendorPayFlag;
	 
	 @Basic
	 @Column(name="qa_ticket_indicator")
	 @JsonProperty("qaTicketIndicator")
	 private String qaTicketIndicator;
	 
	 @Basic
	 @Column(name="tolerance_overriden_flag")
	 @JsonProperty("toleranceOverridenFlag")
	 private String toleranceOverridenFlag;
	 
	 @Basic
	 @Column(name="originator_transaction")
	 @JsonProperty("originatorTransaction")
	 private String originatorTransaction;
	 
	 @Basic
	 @Column(name="invoiced_flag")
	 @JsonProperty("invoicedFlag")
	 private String invoicedFlag;
	 
	 @Basic
	 @Column(name="order_status_code")
	 @JsonProperty("orderStatusCode")
	 private String orderStatusCode;
	 
	 @Basic
	 @Column(name="buyer_number")
	 @JsonProperty("buyerNumber")
	 private String buyerNumber;
	 
	 @Basic
	 @Column(name="purchase_order_no")
	 @JsonProperty("purchaseOrderNo")
	 private String purchaseOrderNo;
	 
	 @Basic
	 @Column(name="po_line_number")
	 @JsonProperty("poLineNumber")
	 private BigDecimal poLineNumber;
	 
	 @Basic
	 @Column(name="remote_stock_accept_subs")
	 @JsonProperty("remoteStockAcceptSubs")
	 private String remoteStockAcceptSubs;
	 
	 @Basic
	 @Column(name="substitute_reference_line_nbr")
	 @JsonProperty("substituteReferenceLineNbr")
	 private BigDecimal substituteReferenceLineNbr;
	 
	 @Basic
	 @Column(name="customer_preference_vendor")
	 @JsonProperty("customerPreferenceVendor")
	 private String customerPreferenceVendor;
	 
	 @Basic
	 @Column(name="free_goods_flag ")
	 @JsonProperty("freeGoodsFlag")
	 private String freeGoodsFlag;
	 
	 @Basic
	 @Column(name="count_as_demand_flag")
	 @JsonProperty("countAsDemandFlag")
	 private String countAsDemandFlag;
	 
	 @Basic
	 @Column(name="subfile_reference_line_number")
	 @JsonProperty("subfileReferenceLineNumber")
	 private BigDecimal subfileReferenceLineNumber;
	 
	 @Basic
	 @Column(name="booking_id")
	 @JsonProperty("bookingId")
	 private BigDecimal bookingId;
	 
	 @Basic
	 @Column(name="order_guide_version_number")
	 @JsonProperty("orderGuideVersionNumber")
	 private BigDecimal orderGuideVersionNumber;
	 
	 @Basic
	 @Column(name="foodshow_promotion_id ")
	 @JsonProperty("foodshowPromotionId")
	 private String foodshowPromotionId;
	 
	 @Basic
	 @Column(name="ship_if_avail_flag")
	 @JsonProperty("shipIfAvailFlag")
	 private String shipIfAvailFlag;
	 
	 @Basic
	 @Column(name="order_reason_code")
	 @JsonProperty("orderReasonCode")
	 private String orderReasonCode;
	 
	 @Basic
	 @Column(name="order_line_error_indicator")
	 @JsonProperty("orderLineErrorIndicator")
	 private String orderLineErrorIndicator;
	 
	 @Basic
	 @Column(name="originally_ordered_item_number")
	 @JsonProperty("originallyOrderedItemNumber")
	 private String originallyOrderedItemNumber;
	 
	 @Basic
	 @Column(name="original_item_customer_pref_vendor")
	 @JsonProperty("originalItemCustomerPrefVendor")
	 private String originalItemCustomerPrefVendor;
	 
	 @Basic
	 @Column(name="referenced_order_number")
	 @JsonProperty("referencedOrderNumber")
	 private BigDecimal referencedOrderNumber;
	 
	 @Basic
	 @Column(name="original")
	 @JsonProperty("original")
	 private String original;
	 
	 @Basic
	 @Column(name="temporary_sub_flag")
	 @JsonProperty("temporarySubFlag")
	 private String temporarySubFlag;
	 
	 @Basic
	 @Column(name="conversion_factor ")
	 @JsonProperty("conversionFactor")
	 private BigDecimal conversionFactor;
	 
	 @Basic
	 @Column(name="item_identifier ")
	 @JsonProperty("itemIdentifier")
	 private String itemIdentifier;
	 
	 @Basic
	 @Column(name="transaction_quantity")
	 @JsonProperty("transactionQuantity")
	 private BigDecimal transactionQuantity;
	 
	 @Basic
	 @Column(name="demand_status")
	 @JsonProperty("demandStatus")
	 private String demandStatus;
	 
	 @Basic
	 @Column(name="stock_type")
	 @JsonProperty("stockType")
	 private String stockType;
	 
	 @Basic
	 @Column(name="reference_detail_line_number")
	 @JsonProperty("referenceDetailLineNumber")
	 private BigDecimal referenceDetailLineNumber;
	 
	 @Basic
	 @Column(name="substitution_reason_code")
	 @JsonProperty("substitutionReasonCode")
	 private String substitutionReasonCode;
	 
	 @Basic
	 @Column(name=" substitution_quantity")
	 @JsonProperty("substitutionQuantity")
	 private BigDecimal substitutionQuantity;
	 
	 @Basic
	 @Column(name="payment_terms_policy")
	 @JsonProperty("paymentTermsPolicy")
	 private String paymentTermsPolicy;
	 
	 @Basic
	 @Column(name="price_calculation_code")
	 @JsonProperty("priceCalculationCode")
	 private String priceCalculationCode;
	 
	 @Basic
	 @Column(name="substitute_request")
	 @JsonProperty("substituteRequest")
	 private String substituteRequest;
	 
	 @Basic
	 @Column(name=" partial_fill_request")
	 @JsonProperty("partialFillRequest")
	 private String partialFillRequest;
	 
	 @Basic
	 @Column(name="major_class")
	 @JsonProperty("majorClass")
	 private String majorClass;
	 
	 @Basic
	 @Column(name="scheduled_receipt_cutoff_time ")
	 @JsonProperty("scheduledReceiptCutoffTime")
	 private BigDecimal scheduledReceiptCutoffTime;
	 
	 @Basic
	 @Column(name="quantity_demanded")
	 @JsonProperty("quantityDemanded")
	 private BigDecimal quantityDemanded;
	 
	 @Basic
	 @Column(name="create_date")
	 @JsonProperty("createDate")
	 private BigDecimal createDate;
	 
	 @Basic
	 @Column(name="create_time")
	 @JsonProperty("createTime")
	 private BigDecimal createTime;
	 
	 @Basic
	 @Column(name="create_user_id")
	 @JsonProperty("createUserId")
	 private String createUserId;
	 
	 @Basic
	 @Column(name="modified_date ")
	 @JsonProperty("modifiedDate")
	 private BigDecimal modifiedDate;
	 
	 @Basic
	 @Column(name=" modified_time")
	 @JsonProperty("modifiedTime")
	 private BigDecimal modifiedTime;
	 
	 @Basic
	 @Column(name="modified_by_id")
	 @JsonProperty("modifiedById")
	 private String modifiedById;
	 
	 @Basic
	 @Column(name="create_timestamp")
	 @JsonProperty("createTimestamp")
	 private Timestamp createTimestamp;
	 
	 @Basic
	 @Column(name="modified_timestamp")
	 @JsonProperty("modifiedTimestamp")
	 private Timestamp modifiedTimestamp;

		public String getSite() {
		return site;
		}

		public void setSite(String site) {
		this.site = site;
		}

		public BigDecimal getOrderNumber() {
		return orderNumber;
		}

		public void setOrderNumber(BigDecimal orderNumber) {
		this.orderNumber = orderNumber;
		}

		public BigDecimal getOrderDetailLineNumber() {
		return orderDetailLineNumber;
		}

		public void setOrderDetailLineNumber(BigDecimal orderDetailLineNumber) {
		this.orderDetailLineNumber = orderDetailLineNumber;
		}

		public String getOrderEntryLineType() {
		return orderEntryLineType;
		}

		public void setOrderEntryLineType(String orderEntryLineType) {
		this.orderEntryLineType = orderEntryLineType;
		}

		public String getItemNumber() {
		return itemNumber;
		}

		public void setItemNumber(String itemNumber) {
		this.itemNumber = itemNumber;
		}

		public String getItemDescription() {
		return itemDescription;
		}

		public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
		}

		public String getLocnCode() {
		return locnCode;
		}

		public void setLocnCode(String locnCode) {
		this.locnCode = locnCode;
		}

		public String getAlternatesIndicator() {
		return alternatesIndicator;
		}

		public void setAlternatesIndicator(String alternatesIndicator) {
		this.alternatesIndicator = alternatesIndicator;
		}

		public String getCompanionsIndicator() {
		return companionsIndicator;
		}

		public void setCompanionsIndicator(String companionsIndicator) {
		this.companionsIndicator = companionsIndicator;
		}

		public String getOrderDetailNotesIndicator() {
		return orderDetailNotesIndicator;
		}

		public void setOrderDetailNotesIndicator(String orderDetailNotesIndicator) {
		this.orderDetailNotesIndicator = orderDetailNotesIndicator;
		}

		public String getDropShipIndicator() {
		return dropShipIndicator;
		}

		public void setDropShipIndicator(String dropShipIndicator) {
		this.dropShipIndicator = dropShipIndicator;
		}

		public String getPricingAgreementsIndicator() {
		return pricingAgreementsIndicator;
		}

		public void setPricingAgreementsIndicator(String pricingAgreementsIndicator) {
		this.pricingAgreementsIndicator = pricingAgreementsIndicator;
		}

		public BigDecimal getQuantity() {
		return quantity;
		}

		public void setQuantity(BigDecimal quantity) {
		this.quantity = quantity;
		}

		public String getSplitCode() {
		return splitCode;
		}

		public void setSplitCode(String splitCode) {
		this.splitCode = splitCode;
		}

		public BigDecimal getQuantityAllocAgainstOnHand() {
		return quantityAllocAgainstOnHand;
		}

		public void setQuantityAllocAgainstOnHand(BigDecimal quantityAllocAgainstOnHand) {
		this.quantityAllocAgainstOnHand = quantityAllocAgainstOnHand;
		}

		public BigDecimal getQuantityAllocAgainstSchReceipts() {
		return quantityAllocAgainstSchReceipts;
		}

		public void setQuantityAllocAgainstSchReceipts(BigDecimal quantityAllocAgainstSchReceipts) {
		this.quantityAllocAgainstSchReceipts = quantityAllocAgainstSchReceipts;
		}

		public String getOrderDetailAllocated() {
		return orderDetailAllocated;
		}

		public void setOrderDetailAllocated(String orderDetailAllocated) {
		this.orderDetailAllocated = orderDetailAllocated;
		}

		public BigDecimal getShipDate() {
		return shipDate;
		}

		public void setShipDate(BigDecimal shipDate) {
		this.shipDate = shipDate;
		}

		public BigDecimal getShippedQuantity() {
		return shippedQuantity;
		}

		public void setShippedQuantity(BigDecimal shippedQuantity) {
		this.shippedQuantity = shippedQuantity;
		}

		public BigDecimal getOriginalItemUnitPrice() {
		return originalItemUnitPrice;
		}

		public void setOriginalItemUnitPrice(BigDecimal originalItemUnitPrice) {
		this.originalItemUnitPrice = originalItemUnitPrice;
		}

		public BigDecimal getOrderDetailExtendedPrice() {
		return orderDetailExtendedPrice;
		}

		public void setOrderDetailExtendedPrice(BigDecimal orderDetailExtendedPrice) {
		this.orderDetailExtendedPrice = orderDetailExtendedPrice;
		}

		public BigDecimal getSuggestedPrice() {
		return suggestedPrice;
		}

		public void setSuggestedPrice(BigDecimal suggestedPrice) {
		this.suggestedPrice = suggestedPrice;
		}

		public String getHandPriceFlag() {
		return handPriceFlag;
		}

		public void setHandPriceFlag(String handPriceFlag) {
		this.handPriceFlag = handPriceFlag;
		}

		public BigDecimal getOrderGuideNumber() {
		return orderGuideNumber;
		}

		public void setOrderGuideNumber(BigDecimal orderGuideNumber) {
		this.orderGuideNumber = orderGuideNumber;
		}

		public String getOrderGuideLineNo() {
		return orderGuideLineNo;
		}

		public void setOrderGuideLineNo(String orderGuideLineNo) {
		this.orderGuideLineNo = orderGuideLineNo;
		}

		public String getCustomerItemNo() {
		return customerItemNo;
		}

		public void setCustomerItemNo(String customerItemNo) {
		this.customerItemNo = customerItemNo;
		}

		public String getCustomerShipTo() {
		return customerShipTo;
		}

		public void setCustomerShipTo(String customerShipTo) {
		this.customerShipTo = customerShipTo;
		}

		public String getShippingAddressId() {
		return shippingAddressId;
		}

		public void setShippingAddressId(String shippingAddressId) {
		this.shippingAddressId = shippingAddressId;
		}

		public String getCustomerCategoryCode() {
		return customerCategoryCode;
		}

		public void setCustomerCategoryCode(String customerCategoryCode) {
		this.customerCategoryCode = customerCategoryCode;
		}

		public BigDecimal getRoutingGroupCode() {
		return routingGroupCode;
		}

		public void setRoutingGroupCode(BigDecimal routingGroupCode) {
		this.routingGroupCode = routingGroupCode;
		}

		public BigDecimal getRequestNumber() {
		return requestNumber;
		}

		public void setRequestNumber(BigDecimal requestNumber) {
		this.requestNumber = requestNumber;
		}

		public String getVendorNumber() {
		return vendorNumber;
		}

		public void setVendorNumber(String vendorNumber) {
		this.vendorNumber = vendorNumber;
		}

		public String getVendorPayFlag() {
		return vendorPayFlag;
		}

		public void setVendorPayFlag(String vendorPayFlag) {
		this.vendorPayFlag = vendorPayFlag;
		}

		public String getQaTicketIndicator() {
		return qaTicketIndicator;
		}

		public void setQaTicketIndicator(String qaTicketIndicator) {
		this.qaTicketIndicator = qaTicketIndicator;
		}

		public String getToleranceOverridenFlag() {
		return toleranceOverridenFlag;
		}

		public void setToleranceOverridenFlag(String toleranceOverridenFlag) {
		this.toleranceOverridenFlag = toleranceOverridenFlag;
		}

		public String getOriginatorTransaction() {
		return originatorTransaction;
		}

		public void setOriginatorTransaction(String originatorTransaction) {
		this.originatorTransaction = originatorTransaction;
		}

		public String getInvoicedFlag() {
		return invoicedFlag;
		}

		public void setInvoicedFlag(String invoicedFlag) {
		this.invoicedFlag = invoicedFlag;
		}

		public String getOrderStatusCode() {
		return orderStatusCode;
		}

		public void setOrderStatusCode(String orderStatusCode) {
		this.orderStatusCode = orderStatusCode;
		}

		public String getBuyerNumber() {
		return buyerNumber;
		}

		public void setBuyerNumber(String buyerNumber) {
		this.buyerNumber = buyerNumber;
		}

		public String getPurchaseOrderNo() {
		return purchaseOrderNo;
		}

		public void setPurchaseOrderNo(String purchaseOrderNo) {
		this.purchaseOrderNo = purchaseOrderNo;
		}

		public BigDecimal getPoLineNumber() {
		return poLineNumber;
		}

		public void setPoLineNumber(BigDecimal poLineNumber) {
		this.poLineNumber = poLineNumber;
		}

		public String getRemoteStockAcceptSubs() {
		return remoteStockAcceptSubs;
		}

		public void setRemoteStockAcceptSubs(String remoteStockAcceptSubs) {
		this.remoteStockAcceptSubs = remoteStockAcceptSubs;
		}

		public BigDecimal getSubstituteReferenceLineNbr() {
		return substituteReferenceLineNbr;
		}

		public void setSubstituteReferenceLineNbr(BigDecimal substituteReferenceLineNbr) {
		this.substituteReferenceLineNbr = substituteReferenceLineNbr;
		}

		public String getCustomerPreferenceVendor() {
		return customerPreferenceVendor;
		}

		public void setCustomerPreferenceVendor(String customerPreferenceVendor) {
		this.customerPreferenceVendor = customerPreferenceVendor;
		}

		public String getFreeGoodsFlag() {
		return freeGoodsFlag;
		}

		public void setFreeGoodsFlag(String freeGoodsFlag) {
		this.freeGoodsFlag = freeGoodsFlag;
		}

		public String getCountAsDemandFlag() {
		return countAsDemandFlag;
		}

		public void setCountAsDemandFlag(String countAsDemandFlag) {
		this.countAsDemandFlag = countAsDemandFlag;
		}

		public BigDecimal getSubfileReferenceLineNumber() {
		return subfileReferenceLineNumber;
		}

		public void setSubfileReferenceLineNumber(BigDecimal subfileReferenceLineNumber) {
		this.subfileReferenceLineNumber = subfileReferenceLineNumber;
		}

		public BigDecimal getBookingId() {
		return bookingId;
		}

		public void setBookingId(BigDecimal bookingId) {
		this.bookingId = bookingId;
		}

		public BigDecimal getOrderGuideVersionNumber() {
		return orderGuideVersionNumber;
		}

		public void setOrderGuideVersionNumber(BigDecimal orderGuideVersionNumber) {
		this.orderGuideVersionNumber = orderGuideVersionNumber;
		}

		public String getFoodshowPromotionId() {
		return foodshowPromotionId;
		}

		public void setFoodshowPromotionId(String foodshowPromotionId) {
		this.foodshowPromotionId = foodshowPromotionId;
		}

		public String getShipIfAvailFlag() {
		return shipIfAvailFlag;
		}

		public void setShipIfAvailFlag(String shipIfAvailFlag) {
		this.shipIfAvailFlag = shipIfAvailFlag;
		}

		public String getOrderReasonCode() {
		return orderReasonCode;
		}

		public void setOrderReasonCode(String orderReasonCode) {
		this.orderReasonCode = orderReasonCode;
		}

		public String getOrderLineErrorIndicator() {
		return orderLineErrorIndicator;
		}

		public void setOrderLineErrorIndicator(String orderLineErrorIndicator) {
		this.orderLineErrorIndicator = orderLineErrorIndicator;
		}

		public String getOriginallyOrderedItemNumber() {
		return originallyOrderedItemNumber;
		}

		public void setOriginallyOrderedItemNumber(String originallyOrderedItemNumber) {
		this.originallyOrderedItemNumber = originallyOrderedItemNumber;
		}

		public String getOriginalItemCustomerPrefVendor() {
		return originalItemCustomerPrefVendor;
		}

		public void setOriginalItemCustomerPrefVendor(String originalItemCustomerPrefVendor) {
		this.originalItemCustomerPrefVendor = originalItemCustomerPrefVendor;
		}

		public BigDecimal getReferencedOrderNumber() {
		return referencedOrderNumber;
		}

		public void setReferencedOrderNumber(BigDecimal referencedOrderNumber) {
		this.referencedOrderNumber = referencedOrderNumber;
		}

		public String getOriginal() {
		return original;
		}

		public void setOriginal(String original) {
		this.original = original;
		}

		public String getTemporarySubFlag() {
		return temporarySubFlag;
		}

		public void setTemporarySubFlag(String temporarySubFlag) {
		this.temporarySubFlag = temporarySubFlag;
		}

		public BigDecimal getConversionFactor() {
		return conversionFactor;
		}

		public void setConversionFactor(BigDecimal conversionFactor) {
		this.conversionFactor = conversionFactor;
		}

		public String getItemIdentifier() {
		return itemIdentifier;
		}

		public void setItemIdentifier(String itemIdentifier) {
		this.itemIdentifier = itemIdentifier;
		}

		public BigDecimal getTransactionQuantity() {
		return transactionQuantity;
		}

		public void setTransactionQuantity(BigDecimal transactionQuantity) {
		this.transactionQuantity = transactionQuantity;
		}

		public String getDemandStatus() {
		return demandStatus;
		}

		public void setDemandStatus(String demandStatus) {
		this.demandStatus = demandStatus;
		}

		public String getStockType() {
		return stockType;
		}

		public void setStockType(String stockType) {
		this.stockType = stockType;
		}

		public BigDecimal getReferenceDetailLineNumber() {
		return referenceDetailLineNumber;
		}

		public void setReferenceDetailLineNumber(BigDecimal referenceDetailLineNumber) {
		this.referenceDetailLineNumber = referenceDetailLineNumber;
		}

		public String getSubstitutionReasonCode() {
		return substitutionReasonCode;
		}

		public void setSubstitutionReasonCode(String substitutionReasonCode) {
		this.substitutionReasonCode = substitutionReasonCode;
		}

		public BigDecimal getSubstitutionQuantity() {
		return substitutionQuantity;
		}

		public void setSubstitutionQuantity(BigDecimal substitutionQuantity) {
		this.substitutionQuantity = substitutionQuantity;
		}

		public String getPaymentTermsPolicy() {
		return paymentTermsPolicy;
		}

		public void setPaymentTermsPolicy(String paymentTermsPolicy) {
		this.paymentTermsPolicy = paymentTermsPolicy;
		}

		public String getPriceCalculationCode() {
		return priceCalculationCode;
		}

		public void setPriceCalculationCode(String priceCalculationCode) {
		this.priceCalculationCode = priceCalculationCode;
		}

		public String getSubstituteRequest() {
		return substituteRequest;
		}

		public void setSubstituteRequest(String substituteRequest) {
		this.substituteRequest = substituteRequest;
		}

		public String getPartialFillRequest() {
		return partialFillRequest;
		}

		public void setPartialFillRequest(String partialFillRequest) {
		this.partialFillRequest = partialFillRequest;
		}

		public String getMajorClass() {
		return majorClass;
		}

		public void setMajorClass(String majorClass) {
		this.majorClass = majorClass;
		}

		public BigDecimal getScheduledReceiptCutoffTime() {
		return scheduledReceiptCutoffTime;
		}

		public void setScheduledReceiptCutoffTime(BigDecimal scheduledReceiptCutoffTime) {
		this.scheduledReceiptCutoffTime = scheduledReceiptCutoffTime;
		}

		public BigDecimal getQuantityDemanded() {
		return quantityDemanded;
		}

		public void setQuantityDemanded(BigDecimal quantityDemanded) {
		this.quantityDemanded = quantityDemanded;
		}

		public BigDecimal getCreateDate() {
		return createDate;
		}

		public void setCreateDate(BigDecimal createDate) {
		this.createDate = createDate;
		}

		public BigDecimal getCreateTime() {
		return createTime;
		}

		public void setCreateTime(BigDecimal createTime) {
		this.createTime = createTime;
		}

		public String getCreateUserId() {
		return createUserId;
		}

		public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
		}

		public BigDecimal getModifiedDate() {
		return modifiedDate;
		}

		public void setModifiedDate(BigDecimal modifiedDate) {
		this.modifiedDate = modifiedDate;
		}

		public BigDecimal getModifiedTime() {
		return modifiedTime;
		}

		public void setModifiedTime(BigDecimal modifiedTime) {
		this.modifiedTime = modifiedTime;
		}

		public String getModifiedById() {
		return modifiedById;
		}

		public void setModifiedById(String modifiedById) {
		this.modifiedById = modifiedById;
		}

		public Timestamp getCreateTimestamp() {
		return createTimestamp;
		}

		public void setCreateTimestamp(Timestamp createTimestamp) {
		this.createTimestamp = createTimestamp;
		}

		public Timestamp getModifiedTimestamp() {
		return modifiedTimestamp;
		}

		public void setModifiedTimestamp(Timestamp modifiedTimestamp) {
		this.modifiedTimestamp = modifiedTimestamp;
		}
	 
	 

}

