package com.mos_1.entity;

import java.math.BigDecimal;
import java.sql.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.mos_1.entityKey.MaintainExclusionKey;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "maintainExclusion")
@IdClass(value = MaintainExclusionKey.class)
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class MaintainExclusion 
{

  @Id
  @Column(name = "site",unique=true, nullable=false)
  @JsonProperty("site")
  private String site;
  
  @Id
  @Column(name = "national_id",unique=true, nullable=false)
  @JsonProperty("nationalId")
  private String nationalId;

  @Id
  @Column(name = "customer_number",unique=true, nullable=false)
  @JsonProperty("customerNumber")
  private String customerNumber;
    
  @Column(name = "site_desc")
  @JsonProperty("siteDesc")
  private String siteDesc;

  @Basic
  @Column(name = "national_name")
  @JsonProperty("nationalName")
  private String nationalName;

  @Basic
  @Column(name = "customer_name")
  @JsonProperty("customerName")
  private String customerName;

  @Basic
  @Column(name = "approval_required_flag")
  @JsonProperty("approvalRequiredFlag")
  private String approvalRequiredFlag;

  @Basic
  @Column(name = "local_central")
  @JsonProperty("localCentral")
  private String localCentral;

  @Basic
  @Column(name = "maintenance_flag")
  @JsonProperty("maintenanceFlag")
  private String maintenanceFlag;

  @Basic
  @Column(name = "national_id_cutoff_time")
  @JsonProperty("nationalIdCutoffTime")
  private BigDecimal nationalIdCutoffTime;

  @Basic
  @Column(name = "route_cutoff_time")
  @JsonProperty("routeCutoffTime")
  private BigDecimal routeCutoffTime;

  @Basic
  @Column(name = "catalog_flag")
  @JsonProperty("catalogFlag")
  private String catalogFlag;

  @Basic
  @Column(name = "account_owner")
  @JsonProperty("accountOwner")
  private String accountOwner;

  @Basic
  @Column(name = "account_phone_no")
  @JsonProperty("accountPhoneNo")
  private String accountPhoneNo;

  @Basic
  @Column(name = "start_of_day")
  @JsonProperty("startOfDay")
  private String startOfDay;

  @Basic
  @Column(name = "future_use_alpha_field1")
  @JsonProperty("futureUseAlphaField1")
  private String futureUseAlphaField1;

  @Basic
  @Column(name = "future_use_alpha_field2")
  @JsonProperty("futureUseAlphaField2")
  private String futureUseAlphaField2;

  @Basic
  @Column(name = "future_use_alpha_field3")
  @JsonProperty("futureUseAlphaField3")
  private String futureUseAlphaField3;

  @Basic
  @Column(name = "future_use8p1")
  @JsonProperty("futureUse8p1")
  private BigDecimal futureUse8p1;

  @Basic
  @Column(name = "future_use8p2")
  @JsonProperty("futureUse8p2")
  private BigDecimal futureUse8p2;

  @Basic
  @Column(name = "future_use8p3")
  @JsonProperty("futureUse8p3")
  private BigDecimal futureUse8p3;

  @Basic
  @Column(name = "create_timestamp")
  @JsonProperty("createTimestamp")
  private Date createTimestamp;

  @Basic
  @Column(name = "created_by_id")
  @JsonProperty("createdById")
  private String createdById;

  @Basic
  @Column(name = "created_by_name")
  @JsonProperty("createdByName")
  private String createdByName;

  @Basic
  @Column(name = "modified_timestamp")
  @JsonProperty("modifiedTimestamp")
  private Date modifiedTimestamp;

  @Basic
  @Column(name = "modified_by_id")
  @JsonProperty("modifiedById")
  private String modifiedById;

  @Basic
  @Column(name = "modified_by_name")
  @JsonProperty("modifiedByName")
  private String modifiedByName;
}

