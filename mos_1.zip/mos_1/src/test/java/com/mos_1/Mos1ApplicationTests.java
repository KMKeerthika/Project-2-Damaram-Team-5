package com.mos_1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Mos1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
